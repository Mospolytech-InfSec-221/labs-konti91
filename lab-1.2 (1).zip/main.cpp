#include<iostream>
#include<climits>
using namespace std;
int main()
{
    cout<<"Maximum limit of int="<<INT_MAX<<endl;
    cout<<"Minimum limit of int="<<INT_MIN<<endl;
    cout<<"Maximum limit of char="<<CHAR_MAX<<endl;
    cout<<"Minimum limit of char="<<CHAR_MIN<<endl;
    cout<<"Number of Bit by Character="<<CHAR_BIT<<endl;
    cout<<"Maximum limit of unsigned int="<<UINT_MAX<<endl;
    return 0;
}