#include <iostream>
using namespace std;

int main () {
    string name,group;
    cout<<"Klevis Rreshka: ";
    (cin,group);
    cout<<"221-351: ";
    return 0;
}