// This file contains "the main" funtion. This is where the program execution starts and ends.
//

#include <iostream>

int main()
{
    std::cout << "Hello Programming Language\n";
}

// Program Launch: CTRL+F5 or the menu "Debug" > "Start without debugging"
// Debug program: F5 or "Debug" menu > "Start Debugging"

// Hints for getting started
// 1. In the Solution Explorer window, you can add and manage files.
// 2. In the Team Explorer window, you can connect to the version control system.
// 3. In the Output window, you can view build output and other messages.
// 4. You can view errors in the "Error List" window.
// 5. Select the menu items "Project" > "Add New Item" to create code files, or "Project" > "Add Existing Item" to add existing code files to the project.
// 6. To reopen this project later, choose File > Open > Project and select the .sln file.

